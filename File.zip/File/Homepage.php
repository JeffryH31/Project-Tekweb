<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="Homepage.css">
</head>

<body>
    <?php
    session_start();
    require_once "connect.php";
    ?>
    <!-- Navigation Bar -->
    <section name="Navigation Bar">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light" id="navbar">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav container-text">
                        <div class="navbar-text">
                            <li class="nav-item">
                                <a class="nav-link" href="Homepage.php">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" aria-current="page" href="MenuPage.php">Menu</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Homepage.php#outletsTitle">Outlets</a>
                            </li>
                        </div>
                        <div class="join-button-container">
                            <?php

                            if (isset($_SESSION['username'])) {
                                $username = $_SESSION['username']; ?>
                                <li class="nav-item welcome-container">
                                    <p class="welcome-text">Welcome,
                                        <?php
                                        if ($_SESSION['role'] == 0) {
                                            $query = "SELECT nama FROM data_user WHERE username='$username' ";
                                        } else if ($_SESSION["role"] == 1) {
                                            $query = "SELECT nama FROM data_admin WHERE username='$username'";
                                        }
                                        $result = mysqli_query($conn, $query);
                                        $row = mysqli_fetch_assoc($result);
                                        $nama = $row["nama"];
                                        echo $nama;
                                        ?>
                                    </p>
                                </li>

                                <li>
                                    <div class="dropdown-centered"><i
                                            class="btn  dropdown fa-solid fa-circle-user profile-logo" role="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <form action="userProfile.php" method="post">
                                                    <button type="submit" class="dropdown-item" name="redirect-profile">User
                                                        Profile </button>
                                                </form>
                                            </li>
                                            <li class="history-button">
                                                <form action="OrderHistory.php" method="post">
                                                    <button type="submit" class="dropdown-item"
                                                        name="redirect-profile">Order History</button>
                                                </form>
                                            </li>
                                            <li><a class="dropdown-item" href="connect.php?logout=true">Logout</a></li>
                                        </ul>
                                    </div>
                                </li>
                            <?php } else { ?>
                                <li class="nav-item">
                                    <button class="join-button signup" onclick="location.href = 'register.php'">Sign
                                        Up</button>
                                </li>
                                <li class="nav-item">
                                    <button class="join-button" onclick="location.href = 'userLogin.php'">Login</button>
                                </li>
                            <?php } ?>
                        </div>
                    </ul>
                </div>
            </div>
        </nav>
    </section>


    <!-- Landing Page -->
    <section class="landing-page">
        <div id="carouselExampleInterval" class="carousel slide landing-container" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active" data-bs-interval="7000">
                    <img src="Asset/Cafe2.png" class="d-block w-100 landing-image">
                    <div class="landing-title">A Taste of Tradition, A Touch of Innovation</div>
                    <div class="landing-text">Experience the best of classic and contemporary flavors at Nongki Cafe
                    </div>
                </div>
                <div class="carousel-item" data-bs-interval="7000">
                    <img src="Asset/Cafe1.png" class="d-block w-100 landing-image">
                    <div class="landing-title">Brewing Up Happiness, One Cup at a Time</div>
                    <div class="landing-text">Come with friends & feel the joy of Nongki Cafe</div>
                </div>
                <div class="carousel-item" data-bs-interval="7000">
                    <img src="Asset/Cafe4.png" class="d-block w-100 landing-image">
                    <div class="landing-title">Embrace the Aroma, and Satisfy Your Cravings</div>
                    <div class="landing-text">Your favourite coffee and treats await at Nongki Cafe</div>
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </section>

    <!-- Signature Menu -->
    <section class="signature-menu">
        <h1 class="section-title" data-aos="zoom-out-down">Our Signature Menu</h1>
        <div class="menu-container">
            <div class="col">
                <div class="card h-100" id="card1" data-aos="flip-right">
                    <img src="Asset/Carbonara.png" class="card-img-top imgCard">
                    <div class="card-body">
                        <h5 class="card-title">Spaghetti Carbonara</h5>
                        <p class="card-text">Creamy pasta tossed with crispy pancetta, a timeless Italian favourite
                            that's both rich and satisfying.</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card h-100" id="card1" data-aos="flip-right">
                    <img src="Asset/Salmon.png" class="card-img-top imgCard">
                    <div class="card-body">
                        <h5 class="card-title">Salmon Steak</h5>
                        <p class="card-text">Grilled salmon fillet served alongside tender asparagus spears, finished
                            with armoatic herbs and a zest of lemon</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card h-100" id="card1" data-aos="flip-right">
                    <img src="Asset/Waffle.png" class="card-img-top imgCard">
                    <div class="card-body">
                        <h5 class="card-title">Ice Cream Waffle</h5>
                        <p class="card-text">A waffle crowned with smooth vanilla ice cream, drizzled honey, walnuts,
                            and fresh berries.</p>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card h-100" id="card1" data-aos="flip-right">
                    <img src="Asset/Passion Squash.png" class="card-img-top imgCard">
                    <div class="card-body">
                        <h5 class="card-title">Passion Squash </h5>
                        <p class="card-text">A refreshing tropical beverage, sparkling water and infused with the exotic
                            sweetness fresh passion fruit</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="view-all">
            <button onclick="location.href='Menupage.php'" class="view-all-button">View All Menu</button>
        </div>
    </section>

    <!-- Outlets Scetion -->
    <section class="outlets-section">
        <div class="overlay">
            <div class="outlets-background">
                <h1 class="section-title outlets-title">Our Outlets</h1>
                <div class="outlets-container">
                    <div class="location-container">
                        <div class="outlets-location-container">
                            <i class="fa-solid fa-location-dot outlets-logo"></i><span class="location-view">G Walk
                                Citraland, Surabaya</span>
                        </div>
                        <span class="alamat" style="padding-left: 2vw;">Jl. Niaga Gapura No.14, Lidah Kulon,
                            Lakarsantri, Surabaya, Jawa
                            Timur</span>
                    </div>
                    <div class="location-container">
                        <div class="outlets-location-container">
                            <i class="fa-solid fa-location-dot outlets-logo"></i><span class="location-view">Pakuwon
                                Mall, Surabaya</span>
                        </div>

                        <span class="alamat">Jl. Mayjend Jonosewojo No.2, Babatan, Kec. Wiyung, Surabaya, Jawa
                            Timur</span>

                    </div>
                    <div class="location-container">
                        <div class="outlets-location-container">
                            <i class="fa-solid fa-location-dot outlets-logo"></i><span class="location-view">Town
                                Square, Malang
                            </span>
                        </div>
                        <span class="alamat" style="padding-left: 2vw;">Jl. Veteran No.2, Penanggungan, Kec. Klojen,
                            Kota Malang, Jawa
                            Timur</span>

                    </div>
                    <div class="location-container">
                        <div class="outlets-location-container">
                            <i class="fa-solid fa-location-dot outlets-logo"></i><span class="location-view">Central
                                Park, Jakarta
                            </span>
                        </div>
                        <span class="alamat">Jl. Letjen S. Parman No.28, Tj, Duren Sel., Kec. Grogol Petamburan,
                            Jakarta</span>
                    </div>
                    <div class="location-container">
                        <div class="outlets-location-container">
                            <i class="fa-solid fa-location-dot outlets-logo"></i><span class="location-view">Senayan
                                City Mall, Jakarta
                            </span>
                        </div>
                        <span class="alamat">Senayan City, Jl. Asia Afrika, Gelora, Kecamatan Tanah Abang, Jakarta
                            Pusat</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <section class="footer-section">
        <footer
            class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top footer-container">
            <div class="col-md-4 d-flex align-items-center">
                <span class="mb-3 mb-md-0 text-body-secondary copyright-text">© 2023 Nongki Cafe Company, Inc</span>
            </div>
            <ul class="nav col-md-4 justify-content-end list-unstyled d-flex sosmed-container">
                <li class="ms-3"><a class="text-body-secondary" href="https://www.instagram.com/"><i
                            class="fa-brands fa-instagram logo-sosmed"></i></a></li>
                <li class="ms-3"><a class="text-body-secondary" href="https://www.twitter.com"><i
                            class="fa-brands fa-twitter logo-sosmed"></i></a></li>
                <li class="ms-3"><a class="text-body-secondary" href="https://www.facebook.com"><i
                            class="fa-brands fa-facebook logo-sosmed"></i></a></li>
                <li class="ms-3"><a class="text-body-secondary" href="https://www.whatsapp.com"><i
                            class="fa-brands fa-whatsapp logo-sosmed"></i></a></li>
            </ul>
        </footer>
    </section>

    <script>
        AOS.init();
    </script>
</body>

</html>