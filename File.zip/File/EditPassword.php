<!DOCTYPE html>
<html>

<head>
    <title>Change Password</title>
    <link rel="stylesheet" href="EditPassword.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>
    <?php
    require_once('connect.php');
    if (isset($_POST["submit"])) {
        $username = $_POST["username"];
        $query1 = "SELECT * FROM data_user WHERE username = '$username'";
        $result = mysqli_query($conn, $query1);
        $row = $result->fetch_assoc();
        $emailAsli = $row["email"];
        $emailInput = $_POST["email"];
        if (mysqli_num_rows($result) < 1) {
            $error_message = "Username Not Found!";
        } else if ($emailInput != $emailAsli) {
            $error_message = "Email Incorrect!";
        } else {
            $password1 = $_POST["password1"];
            $password2 = $_POST["password2"];
        }
        if ($password1 !== $password2) {
            $error_message = "Password confirmation doesn't match!";
        } else {
            $query2 = "UPDATE data_user SET password = ? WHERE username = ?";
            $stmt = $conn->prepare($query2);
            $password = password_hash($password1, PASSWORD_DEFAULT);
            $stmt->bind_param("ss", $password, $username);
            $stmt->execute();
            $stmt->close();
            ?>
            <script>Swal.fire({
                    title: 'Success',
                    text: 'Password Has Changed!',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'UserLogin.php';
                    }
                });</script>
            <?php
        }

    }
    ?>
    <div class="kotak_transparan"></div>
    <div class="main-container">
        <div class="forgot-password-container">
            <form action="" method="post">
                <a href="Homepage.php"><img id="logo" src="img/logowkwk.PNG" alt="Logo"></a>
                <h2>Change Password</h2>
                <?php if (isset($_POST["submit"]) && isset($error_message)) { ?>
                    <p class="error-message">
                        <script>
                            Swal.fire({
                                title: 'Error',
                                text: '<?php echo $error_message; ?>',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = 'EditPassword.php';
                                }
                            });
                        </script>
                    </p>
                <?php } ?>
                <div class="input-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email" required>
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" required>
                    <label for="pass1">New Password</label>
                    <input type="password" name="password1" id="pass1" required>
                    <label for="pass2">Confirm New Password</label>
                    <input type="password" name="password2" id="pass2" required>
                </div>
                <button type="submit" name="submit" class="submit-change">Submit Changes</button>
            </form>
            <p>Back To <a href="userLogin.php" style="font-weight:bold;">Login Page</a></p>
        </div>
    </div>
</body>

<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    };
</script>

</html>