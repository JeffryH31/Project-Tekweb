<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Form</title>
    <link rel="stylesheet" href="register.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>

<body>
    <?php
    require_once('connect.php');
    $hasilRegistrasi = '';
    $email = $username = $name = '';


    // cek apakah tombol SUBMIT sudah ditekan
    if (isset($_POST["register"])) {
        $hasilRegistrasi = registrasi($_POST);

        if ($hasilRegistrasi === '') {
            ?>
            <script>Swal.fire({
                    title: 'Success',
                    text: 'Account Successfully Made!',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'UserLogin.php';
                    }
                });</script>
            <?php
        }
        $email = $_POST['email'];
        $username = $_POST['username'];
        $name = $_POST['nama'];
    }
    ?>

    <div class="kotak_transparan"></div>
    <div class="wrapper">
        <div class="register-container">
            <a href="Homepage.php"><img id="logo" src="Asset/logowkwk.PNG" alt="Logo"></a>
            <form action="" method="post" class="register-form">
                <h2>Create an Account</h2>
                <?php if ($hasilRegistrasi) { ?>
                    <p class="error-message">
                        <script>
                            Swal.fire({
                                title: 'Error',
                                text: '<?php echo $hasilRegistrasi ?>',
                                icon: 'error',
                            })
                        </script>
                    </p>
                <?php } ?>
                <div class="form-group">
                    <input type="email" id="email" name="email" placeholder="Email address" required
                        value="<?php echo htmlspecialchars($email); ?>">
                </div>
                <div class="form-group">
                    <input type="text" id="username" name="username" placeholder="Username" required maxlength="20"
                        value="<?php echo htmlspecialchars($username); ?>">
                </div>
                <div class="form-group">
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <input type="password" id="password2" name="password2" placeholder="Confirm Password" required>
                </div>
                <div class="form-group">
                    <input type="text" id="name" name="nama" placeholder="Name" required
                        value="<?php echo htmlspecialchars($name); ?>">
                </div>
                <button type="submit" name="register">Register</button>
                <p class="signin">Already have an account? <a href="UserLogin.php">Login</a></p>
            </form>
        </div>
    </div>

    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        };
    </script>
</body>

</html>