<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <title>User Login Page</title>
  <link rel="stylesheet" href="UserLogin.css">
</head>


<body>
  <?php
  require_once 'connect.php';

  if (isset($_POST["submit"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $query = "SELECT * FROM data_user WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    // Memeriksa apakah username ditemukan dalam database
    if (mysqli_num_rows($result) === 1) {
      $row = mysqli_fetch_assoc($result);
      // Memeriksa apakah password yang dimasukkan cocok dengan password di database
      if (password_verify($password, $row["password"])) {
        session_start();
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = 0;
        header("Location: Homepage.php");
        exit;
      } else {
        $error_message = "Password salah!";
      }
    } else {
      $error_message = "Username tidak ditemukan!";
    }
  }
  ?>

  <div class="main-container">
    <div class="login-container">
      <a href="Homepage.php"><img id="logo" src="img/logowkwk.PNG" alt="Logo"></a>
      <h2>Login</h2>
      <?php if (isset($error_message)) { ?>
        <p class="error-message">
          <script>
            Swal.fire({
              title: 'Error',
              text: '<?php echo $error_message; ?>',
              icon: 'error',
            })
          </script>
        </p>
      <?php } ?>
      <div class="input-group">
        <form action="" method="post">
          <label for="username">Username</label>
          <input type="text" name="username" id="username" required>
      </div>
      <div class="input-group">
        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>
        <p class="text"><a href="EditPassword.php">Forgot Password?</a></p>
      </div>
      <button type="submit" name="submit">Login</button>
      </form>
      <p>Don't have an account? <a href="Register.php" class="text">Register Here</a></p>
    </div>
    <div class="image-slider-container">
      <img class="slide" src="img/phonto.jpg" />
      <img class="slide" src="Asset/Fish and Chips.png" />
      <img class="slide" src="Asset/Dory.png" />
      <img class="slide" src="Asset/Waffle.png" />
    </div>
  </div>


</body>
<script>
  let slideIndex = 0;
  showSlides();

  function showSlides() {
    let i;
    let slides = document.getElementsByClassName("slide");
    for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > slides.length) {
      slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = "block";
    setTimeout(showSlides, 2750);
  }

  if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
  };
</script>

</html>