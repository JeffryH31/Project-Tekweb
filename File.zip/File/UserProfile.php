<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="UserProfile.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Document</title>
</head>

<body>
    <?php
    session_start();
    require_once("connect.php");

    if (isset($_SESSION["username"])) {
        $username = $_SESSION["username"];
        $query = "SELECT * FROM data_user WHERE username ='$username'";
        $result = mysqli_query($conn, $query);
        $row = mysqli_fetch_array($result);
        $email = $row["email"];
        $saldo = $row["saldo"];
        $nama_user = $row["nama"];
    }
    ?>

    <div class="profile-container">
        <div class="logo-container">
            <i class="fa-solid fa-circle-user profile-logo"></i>
        </div>
        <div class="info-container">
            <form action="" method="post">
                <p>Name:<input type="text" class="input-nama" name="nama-baru" value=" <?php echo $nama_user ?>">
                    <span class="print-nama">
                        <?php echo $nama_user ?>
                    </span>
                    <button type="button" class="edit-nama"><i class="fa-solid fa-pencil edit-logo"></i></button>
                    <button type="submit" name="ganti-nama" class="confirm-nama">Confirm</button>
            </form>
            </p>
            <form action="" method="post">
                <p>Email:<input type="email" class="input-email" name="email-baru" value=" <?php echo $email ?>">
                    <span class="print-email">
                        <?php echo $email ?>
                    </span>
                    <button type="button" class="edit-email"><i class="fa-solid fa-pencil edit-logo"></i></button>
                    <button type="submit" name="ganti-email" class="confirm-email">Confirm</button>
                </p>
            </form>
            <p>Saldo:
                <?php echo 'Rp' . number_format($saldo, 0, '.', '.') . ',-' ?>

            </p>
        </div>

        <div class="top-up">
            <button class="top-up-button">Top Up</button>
            <form action="" method="post">
                <input type="number" min="10000" value="10000" name="nominal" class="input-saldo">
                <button type="submit" name="bayar" class="confirm-button">Confirm</button>
            </form>
        </div> <button class="edit-pass" onclick="location.href='EditPassword.php'">Change Password</button>
        <div class="button-container">
            <button class="home" onclick="location.href='Homepage.php'">Back to Homepage</button>
            <button class="logout" type="button" onclick="location.href='connect.php?logout=true'">
                Logout
            </button>
        </div>
    </div>

    <?php
    if (isset($_POST["bayar"])) {
        $jumlahTopup = $_POST["nominal"];
        $username = $_SESSION["username"];
        $query2 = "SELECT saldo FROM data_user WHERE username = '$username'";
        $result = mysqli_query($conn, $query2);
        $row = mysqli_fetch_assoc($result);
        $currentSaldo = $row["saldo"];
        $totalSaldo = $jumlahTopup + $currentSaldo;
        $query = "UPDATE data_user SET saldo = ? WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $totalSaldo, $username);
        $stmt->execute();
        $stmt->close();
        ?>
        <script>Swal.fire({
                title: 'Success',
                text: 'Top Up Success!',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'UserProfile.php';
                }
            });</script>
        <?php
    }

    if (isset($_POST["ganti-nama"])) {
        $namaBaru = $_POST["nama-baru"];
        $query = "UPDATE data_user SET nama = ? WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $namaBaru, $username);
        $stmt->execute();
        $stmt->close();
        ?>
        <script>Swal.fire({
                title: 'Success',
                text: 'Name Changed!',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'UserProfile.php';
                }
            });</script>
        <?php
    }

    if (isset($_POST["ganti-email"])) {
        $emailBaru = $_POST["email-baru"];
        $query = "UPDATE data_user SET email = ? WHERE username = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $emailBaru, $username);
        $stmt->execute();
        $stmt->close();
        ?>
        <script>Swal.fire({
                title: 'Success',
                text: 'Email Changed!',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'UserProfile.php';
                }
            });</script>
        <?php
    }
    ?>


    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        };

        $(document).ready(function () {
            $(".top-up-button").click(function () {
                $(".input-saldo").toggleClass("muncul");
                $(".confirm-button").toggleClass("muncul");
            });
        });

        $(document).ready(function () {
            $(".edit-nama").click(function () {
                $(".input-nama").toggleClass("appear");
                $(".confirm-nama").toggleClass("muncul");
                $(".print-nama").toggleClass("hilang");
            });
        });

        $(document).ready(function () {
            $(".edit-email").click(function () {
                $(".confirm-email").toggleClass("muncul");
                $(".input-email").toggleClass("appear");
                $(".print-email").toggleClass("hilang");
            });
        });
    </script>
</body>

</html>