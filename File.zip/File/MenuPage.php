<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Nongki Cafe Website</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="MenuPage.css">
</head>

<body>

    <!-- Navigation Bar -->
    <section name="Navigation Bar">
        <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light" id="navbar">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav container-text">
                        <?php
                        session_start();
                        require_once '../Home and Login/connect.php';
                        if (!isset($_SESSION['role']) || $_SESSION['role'] == 0) {
                            ?>
                            <div class="navbar-text">
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" aria-current="page" href="#menu-title">Menu</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#outletsTitle ">Outlets</a>
                                </li>
                            </div>
                        <?php } else { ?>
                            <div class="navbar-text">
                                <li class="nav-item">
                                    <button id="homepage-button"
                                        onclick="window.location.href='../Home and Login/Homepage.php'">Homepage</button>
                                </li>
                                <li class="nav-item">
                                    <button id="insert-button" data-bs-target="#modal-insert" data-bs-toggle="modal">Insert
                                        Menu</button>
                                </li>

                            </div>
                        <?php } ?>
                        <div class="navbar-button-container">
                            <?php

                            // require('../Home and Login/connect.php');
                            if (isset($_SESSION['username'])) {
                                $username = $_SESSION['username'];

                                if ($_SESSION['role'] == 0) {
                                    ?>
                                    <li class="nav-item">
                                        <i class="fa-solid fa-cart-shopping cart-logo" id="cart-open"></i>
                                    </li>

                                <?php } ?>
                                <li class="nav-item welcome-container">
                                    <p class="welcome-text">Welcome,
                                        <?php
                                        if ($_SESSION['role'] == 0) {
                                            $query = "SELECT nama FROM data_user WHERE username='$username'";
                                        } else if ($_SESSION["role"] == 1) {
                                            $query = "SELECT nama FROM data_admin WHERE username='$username'";
                                        }
                                        $result = mysqli_query($conn, $query);
                                        $row = mysqli_fetch_assoc($result);
                                        $nama = $row["nama"];
                                        echo $nama;
                                        ?>
                                    </p>
                                </li>
                                <li>
                                    <div class="dropdown-center"><i
                                            class="btn dropdown fa-solid fa-circle-user profile-logo" role="button"
                                            data-bs-toggle="dropdown" aria-expanded="false"></i>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="profilePage.php">User Profile</a></li>
                                            <li><a class="dropdown-item"
                                                    href="connect.php?logout=true">Logout</a></li>

                                        </ul>
                                    </div>
                                </li>

                            <?php } else { ?>
                                <li class="nav-item">
                                    <button class="join-button" onclick="location.href = 'register.php'">Sign Up</button>
                                </li>
                                <li class="nav-item">
                                    <button class="join-button"
                                        onclick="location.href = 'userLogin.php'">Login</button>
                                </li>
                            <?php } ?>
                        </div>
                    </ul>
                </div>
            </div>
        </nav>
    </section>

    <br /><br /><br />
    <div class="sidebar">
        <ul>
            <li>
                <p>INI ITEM 1</p>
            </li>
            <li>
                <p>ini ITEM 2 LO</p>
            </li>
        </ul>
    </div>

    <!-- Insert Menu HTML -->
    <div class="insert-food">
        <div class="modal fade" id="modal-insert" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Insert Menu</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body insert-modal">
                        <form action="" method="post" enctype="multipart/form-data">
                            <div class="insert-input">
                                <label for="nama-menu">Nama menu</label>
                                <input type="text" name="nama" id="nama-menu" required />
                            </div>
                            <div class="insert-input">
                                <label for="harga-menu">Harga menu</label>
                                <input type="text" name="harga" id="harga-menu" required />
                            </div>
                            <div class="insert-input">
                                <label for="stock-menu">Stock menu</label>
                                <input type="number" name="stock" id="stock-menu" required />
                            </div>
                            <div class="insert-input">
                                <label>Kategori menu : </label>

                                <input type="radio" name="kategori" id="kategori1" value="1" required />
                                <label for="kategori1">Food</label>
                                <input type="radio" name="kategori" id="kategori2" value="2" required />
                                <label for="kategori1">Beverage</label>
                                <input type="radio" name="kategori" id="kategori3" value="3" required />
                                <label for="kategori1">Dessert</label>
                            </div>
                            <div class="insert-input">
                                <label for="gambar">Upload gambar menu:</label>
                                <input type="file" name="gambar" id="gambar-menu" required />
                            </div>
                    </div>
                    <div class="modal-footer modal-buttons">
                        <button type="submit" name="submit-menu" class="btn btn-primary">Add to Menu</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Insert Menu PHP -->
    <?php
    if (isset($_POST["submit-menu"])) {
        $nama_menu = $_POST["nama"];
        $harga_menu = $_POST["harga"];
        $stock = $_POST["stock"];
        $kategori = $_POST["kategori"];
        $gambar = file_get_contents($_FILES["gambar"]["tmp_name"]);
        $command = "INSERT INTO data_menu (nama,harga,gambar,stock, kategori) VALUES (?,?,?,?,?)";
        $stmt = $conn->prepare($command);
        $stmt->bind_param("sssss", $nama_menu, $harga_menu, $gambar, $stock, $kategori);
        $stmt->execute();
        $stmt->close();
        echo '<script>window.location.href = "MenuPage.php";</script>';
    }
    ?>



    <!-- Edit Menu PHP -->
    <?php

    if (isset($_POST["edit-food"])) {
        $command = "UPDATE foods SET nama = ?, harga = ?, gambar = ? WHERE id_food = ?";
        $id = $_POST['id-edit'];
        $nama = $_POST['nama-edit'];
        $harga = $_POST['harga-edit'];
        $gambar = file_get_contents($_FILES["gambar-edit"]["tmp_name"]);
        $stmt = $conn->prepare($command);
        $stmt->bind_param("ssss", $nama, $harga, $gambar, $id);
        $stmt->execute();
        $stmt->close();
        echo '<script>window.location.href = "MenuPage.php";</script>';
    } else if (isset($_POST["edit-beverages"])) {
        $command = "UPDATE beverages SET nama = ?, harga = ?, gambar = ? WHERE id_beverage = ?";
        $id = $_POST['id-edit'];
        $nama = $_POST['nama-edit'];
        $harga = $_POST['harga-edit'];
        $gambar = file_get_contents($_FILES["gambar-edit"]["tmp_name"]);
        $stmt = $conn->prepare($command);
        $stmt->bind_param("ssss", $nama, $harga, $gambar, $id);
        $stmt->execute();
        $stmt->close();
        echo '<script>window.location.href = "MenuPage.php";</script>';
    } else if (isset($_POST["edit-dessert"])) {
        $command = "UPDATE dessert SET nama = ?, harga = ?, gambar = ? WHERE id_dessert = ?";
        $id = $_POST['id-edit'];
        $nama = $_POST['nama-edit'];
        $harga = $_POST['harga-edit'];
        $gambar = file_get_contents($_FILES["gambar-edit"]["tmp_name"]);
        $stmt = $conn->prepare($command);
        $stmt->bind_param("ssss", $nama, $harga, $gambar, $id);
        $stmt->execute();
        $stmt->close();
        echo '<script>window.location.href = "MenuPage.php";</script>';
    }
    ?>



    <!-- Delete Menu Modal -->
    <div class="modal fade" id="modal-delete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post">
                        <div class="insert-input">
                            <label for="id-del">Please enter menu ID to confirm action</label>
                            <input type="text" name="id-delete" required />
                        </div>
                </div>
                <div class="modal-footer modal-buttons">
                    <button type="submit" name="delete-menu" class="btn btn-primary">Confirm Delete</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Delete Menu PHP -->
    <?php
    if (isset($_POST["delete-menu"])) {
        $id = $_POST["id-delete"];
        $command = "DELETE FROM data_menu WHERE id_menu =  ? ";
        $stmt = $conn->prepare($command);
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $stmt->close();
        echo '<script>window.location.href = "MenuPage.php";</script>';
    }
    ?>




    <!-- Print Menu -->
    <h2 class="menu-title">FOODS</h2>
    <?php
    $result = $conn->query("SELECT * FROM data_menu WHERE kategori = 1");
    $counter = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($counter % 5 == 0) {
                echo '<div class="menu-container">';
            }

            echo '<div class="col">
            <div class="card h-100" id="card1">
                <img src="data:image/jpeg;base64,' . base64_encode($row["gambar"]) . '" class="card-img-top" alt="' . $row["nama"] . '" class="imgCard" />
                <div class="card-body">
                    <h5 class="card-title">';
            if ((isset($_SESSION["username"])) && $_SESSION['role'] == 1)
                echo $row["nama"] . '(' . $row["id_menu"] . ')' . '</h5>';
            else
                echo $row["nama"] . '</h5>';


            echo '<h6>Rp' . $row["harga"] . ',-</h6>';



            if (isset($_SESSION["username"]) && $_SESSION["role"] == 1) { ?>
                <button id="edit-button" data-bs-target="#modal-edit" data-bs-toggle="modal">Edit Menu</button>
                <button id="delete-button" data-bs-target="#modal-delete" data-bs-toggle="modal">Delete Menu</button>
                <?php
            } else if (isset($_SESSION["username"]) && $_SESSION["role"] == 0) { ?>
                    <form action="" method="post">
                        <input type="hidden" name="<?php echo 'data-menu' . $row["id_menu"]; ?>" value="<?php echo $row["id_menu"]; ?>">
                        <input type="hidden" name="data-user" value="<?php echo $_SESSION['username']; ?>">
                        <input type="number" name="menu-quantity" min="1" max="<?php echo $row["stock"] ?>" value="1">
                        <button class="add-cart" type="submit" name="<?php echo 'submit-cart' . $row["id_menu"]; ?>">Add to
                            Cart</button>
                    </form>
                <?php
            } else {
                ?>
                    <input type="number" name="menu-quantity" min="1">
                    <button class="add-cart" onclick="window.location.href='../Home and Login/userLogin.php'">Add to Cart</button>
                <?php
            }
            echo '</div>
            </div>
            </div>';
            if (isset($_POST["submit-cart" . $row["id_menu"]]) && isset($_SESSION["username"])) {
                $id_menu = $_POST["data-menu" . $row["id_menu"]];
                $id_user = $_POST["data-user"];

                $quantity = $_POST["menu-quantity"];
                $query = "INSERT INTO order_cart (id_user, id_menu, quantity) VALUES (?,?,?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sii", $id_user, $id_menu, $quantity);
                $stmt->execute();
                $stmt->close();

            }
            if ($counter % 5 == 4) {
                echo '</div>';
            }
            $counter++;
        }
        echo '</div>';
    }
    ?>




    <h2 class="menu-title">BEVERAGES</h2>

    <?php
    $result = $conn->query("SELECT * FROM data_menu WHERE kategori = 2");
    $counter = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($counter % 5 == 0) {
                echo '<div class="menu-container">';
            }

            echo '<div class="col">
            <div class="card h-100" id="card1">
                <img src="data:image/jpeg;base64,' . base64_encode($row["gambar"]) . '" class="card-img-top" alt="' . $row["nama"] . '" class="imgCard" />
                <div class="card-body">
                    <h5 class="card-title">';
            if ((isset($_SESSION["username"])) && $_SESSION['role'] == 1)
                echo $row["nama"] . '(' . $row["id_menu"] . ')' . '</h5>';
            else
                echo $row["nama"] . '</h5>';


            echo '<h6>Rp' . $row["harga"] . ',-</h6>';


            if (isset($_SESSION["username"]) && $_SESSION["role"] == 1) { ?>
                <button id="edit-button">Edit Menu</button>
                <button id="delete-button">Delete Menu</button>
                <?php
            } else if (isset($_SESSION["username"]) && $_SESSION["role"] == 0) { ?>
                    <form action="" method="post">
                        <input type="hidden" name="<?php echo 'data-menu' . $row["id_menu"]; ?>" value="<?php echo $row["id_menu"]; ?>">
                        <input type="hidden" name="data-user" value="<?php echo $_SESSION['username']; ?>">
                        <label for="#qty">Quantity : </label>
                        <input type="number" name="menu-quantity" min="1" max="<?php echo $row["stock"] ?>" value="1" id="qty">
                        <button class="add-cart" type="submit" name="<?php echo 'submit-cart' . $row["id_menu"]; ?>">Add to
                            Cart</button>
                    </form>
                <?php
            } else {
                ?>
                    <input type="number" name="menu-quantity" min="1">
                    <button class="add-cart" onclick="window.location.href='../Home and Login/userLogin.php'">Add to Cart</button>
                <?php
            }
            echo '</div>
            </div>
            </div>';
            if (isset($_POST["submit-cart" . $row["id_menu"]]) && isset($_SESSION["username"])) {
                $id_menu = $_POST["data-menu" . $row["id_menu"]];
                $id_user = $_POST["data-user"];

                $quantity = $_POST["menu-quantity"];
                $query = "INSERT INTO order_cart (id_user, id_menu, quantity) VALUES (?,?,?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sii", $id_user, $id_menu, $quantity);
                $stmt->execute();
                $stmt->close();

            }
            if ($counter % 5 == 4) {
                echo '</div>';
            }
            $counter++;
        }
        echo '</div>';
    }
    ?>


    <h2 class="menu-title">DESSERT</h2>
    <?php
    $result = $conn->query("SELECT * FROM data_menu WHERE kategori = 3");
    $counter = 0;

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($counter % 5 == 0) {
                echo '<div class="menu-container">';
            }

            echo '<div class="col">
            <div class="card h-100" id="card1">
                <img src="data:image/jpeg;base64,' . base64_encode($row["gambar"]) . '" class="card-img-top" alt="' . $row["nama"] . '" class="imgCard" />
                <div class="card-body">
                    <h5 class="card-title">';
            if ((isset($_SESSION["username"])) && $_SESSION['role'] == 1)
                echo $row["nama"] . '(' . $row["id_menu"] . ')' . '</h5>';
            else
                echo $row["nama"] . '</h5>';


            echo '<h6>Rp' . $row["harga"] . ',-</h6>';



            if (isset($_SESSION["username"]) && $_SESSION["role"] == 1) { ?>
                <form action="" method="post" id="edit-form" onsubmit="preventRefresh()">
                    <input type="hidden" name="<?php echo 'id_edit' . $row["id_menu"]; ?>" value="<?php echo $row["id_menu"]; ?>">
                    <button type="submit" name="<?php echo 'edit-submit' . $row["id_menu"]; ?>" id="edit-button">Edit Menu</button>
                </form>

                <?php

                ?>
                <button id="delete-button">Delete Menu</button>

                <?php
            } else if (isset($_SESSION["username"]) && $_SESSION["role"] == 0) { ?>
                    <form action="" method="post">
                        <input type="hidden" name="<?php echo 'data-menu' . $row["id_menu"]; ?>" value="<?php echo $row["id_menu"]; ?>">
                        <input type="hidden" name="data-user" value="<?php echo $_SESSION['username']; ?>">
                        <input type="number" name="menu-quantity" min="1" max="<?php echo $row["stock"] ?>" value="1">
                        <button class="add-cart" type="submit" name="<?php echo 'submit-cart' . $row["id_menu"]; ?>">Add to
                            Cart</button>
                    </form>
                <?php
            } else {
                ?>
                    <input type="number" name="menu-quantity" min="1">
                    <button class="add-cart" onclick="window.location.href='../Home and Login/userLogin.php'">Add to Cart</button>
                <?php

            }
            ?>
            </div>
            </div>
            </div>

            <?php if (isset($_POST["submit-cart" . $row["id_menu"]]) && isset($_SESSION["username"])) {
                $id_menu = $_POST["data-menu" . $row["id_menu"]];
                $id_user = $_POST["data-user"];

                $quantity = $_POST["menu-quantity"];
                $query = "INSERT INTO order_cart (id_user, id_menu, quantity) VALUES (?,?,?)";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("sii", $id_user, $id_menu, $quantity);
                $stmt->execute();
                $stmt->close();
            }

            if (isset($_POST["edit-submit" . $row["id_menu"]])) {
                $id_temp = $_POST["id_edit" . $row["id_menu"]];

            }
            if ($counter % 5 == 4) {
                echo '</div>';
            }
            $counter++;
        }
        echo '</div>';
    }
    ?>
    <!-- EDIT Menu Modal -->
    <div class="modal fade" id="modal-edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Menu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="insert-input">
                            <label for="nama-menu">ID menu</label>
                            <input type="text" name="id-edit" id="id-menu" value="<?php echo $id_edit ?>" required />
                        </div>
                        <div class="insert-input">
                            <label for="nama-menu">Nama menu</label>
                            <input type="text" name="nama-edit" id="nama-menu" value="<?php echo $nama_edit ?>"
                                required />
                        </div>
                        <div class="insert-input">
                            <label for="harga">Harga menu</label>
                            <input type="text" name="harga-edit" id="harga-menu" required />
                        </div>
                        <div class="insert-input">
                            <label for="harga">Stock menu</label>
                            <input type="number" min="1" name="stock-edit" id="stock-menu" required />
                        </div>
                        <div class="insert-input">
                            <label for="gambar">Gambar menu</label>
                            <br>
                            <input type="file" name="gambar-edit" id="gambar-menu" required />
                        </div>
                </div>
                <div class="modal-footer modal-buttons">
                    <button type="submit" name="edit-menu" class="btn btn-primary">Edit menu</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <br><br>
    <script>
        $('.cart-logo').click(function () {
            $('.sidebar').toggleClass("show");
        });

        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        };

        function preventRefresh(e) {
            event.preventDefault()
            var myModal = new bootstrap.Modal(document.getElementById('modal-edit'));
            myModal.show();
        };


    </script>
</body>

</html>