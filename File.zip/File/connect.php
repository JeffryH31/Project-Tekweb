<?php
$conn = mysqli_connect("localhost", "root", "", "project_tekweb");

function query($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function registrasi($data)
{
    global $conn;
    $error = '';
    $username = stripslashes($data["username"]);
    $password = $data["password"];
    $password2 = $data["password2"];
    $email = strtolower(stripslashes($data["email"]));
    $nama = stripslashes($data["nama"]);

    // Cek apakah username sudah ada
    $resultusername = mysqli_query($conn, "SELECT username FROM data_user WHERE username = '$username'");
    if (mysqli_fetch_assoc($resultusername)) {
        $error = 'username sudah digunakan!';
        return $error; // username sudah ada, registrasi gagal
    }

    // Cek apakah email sudah terdaftar
    $resultEmail = mysqli_query($conn, "SELECT email FROM data_user WHERE email = '$email'");
    if (mysqli_fetch_assoc($resultEmail)) {
        $error = 'Email sudah terdaftar!';
        return $error; // Email sudah terdaftar, registrasi gagal
    }

    // Cek kecocokan password
    if ($password !== $password2) {
        $error = 'Konfirmasi Password tidak sesuai!';
        return $error; // Password tidak cocok, registrasi gagal
    }

    // Enkripsi password
    $password = password_hash($password, PASSWORD_DEFAULT);

    // Tambah user baru ke database
    mysqli_query($conn, "INSERT INTO data_user VALUES ('$username', '$password','$email', '$nama', '', '')");
    return $error;
}
function destroy()
{
    session_start();
    session_destroy();
}

if (isset($_GET["logout"])) {
    destroy();
    header("location: Homepage.php");
}
?>